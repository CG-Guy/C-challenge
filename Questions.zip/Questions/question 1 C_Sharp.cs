﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;


namespace C__folder
{

  
        public class Area
        {
            public int ID {get; set;}
            public int ParentID{get;set;}
            public string Description{get; set;}

            public Area(int id_, int parentid_, string description_)
            {
                ID = id_;
                ParentID = parentid_;
                Description = description_;
            
            }

        }

    class Program
    {
               
        static void Main()
        {

            //Set container
                var list = new List<Area>()
                {
                        new Area(1,0,"Continent"),
                        new Area(2,1,"Country"),
                        new Area(3,2,"Province"),
                        new Area(4,3,"City1"),
                        new Area(5,6,"Suburb1"),
                        new Area(6,3,"City2"),
                        new Area(7,6,"Suburb2"),
                        new Area(8,6,"Suburb3"),
                        new Area(9,4,"Suburb4"),
                        new Area(10,7,"House1"),
                        new Area(11,9,"House3"),
                        new Area(12,8,"House4"),
                        new Area(13,8,"House5"),
                        new Area(14,7,"House6")
                };

            // var reordered = list.Where(p => p.ParentID == 0) //Assign ParentID to zero
            // .OrderBy(p=> p.ID) //Order by ID
            //.Select(p => list  //send to list
            // .Where(c => c.ParentID == p.ID) // Compare the parentID with the ID 
            // .OrderBy(c => c.ID)) //Order according to comparison results
            // .ToList();// send to list

            // var list2= new List<Area>();

            //Call GetStr function
            list.ForEach(element_Value => Console.WriteLine($" { GetStr(list,element_Value) } " ));

            Console.ReadLine();
        }

            static string GetStr(List<Area> list_all, Area present)
            {
                string P = "-";
                Action<List<Area>, Area> GetP = null;
                GetP = (List<Area> area, Area current) => 
                {
                    var parents = list_all.Where(y => y.ID == current.ParentID);
                    foreach(var parent in parents)
                    {
                        P += "-";//Add dash for each child according to parent location
                        GetP(area, parent);
                        // Console.WriteLine($"current parent: {parent.Description}");
                    }
                };
                string areaString = "";
                GetP(list_all, present);
                areaString = P + present.Description;
                return areaString;

            }

    }
}

